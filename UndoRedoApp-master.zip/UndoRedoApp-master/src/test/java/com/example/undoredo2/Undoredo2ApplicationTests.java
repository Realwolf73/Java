package com.example.undoredo2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Undoredo2ApplicationTests {

    @Test
    void contextLoads() {
    }

}
