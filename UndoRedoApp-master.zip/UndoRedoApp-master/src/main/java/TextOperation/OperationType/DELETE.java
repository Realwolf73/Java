package TextOperation.OperationType;

public class DELETE {
}
