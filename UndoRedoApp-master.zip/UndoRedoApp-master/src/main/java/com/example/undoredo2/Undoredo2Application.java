package com.example.undoredo2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Undoredo2Application {

    public static void main(String[] args) {
        SpringApplication.run(Undoredo2Application.class, args);
    }

}
