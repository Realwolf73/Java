package com.example.printerqueue2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Printerqueue2ApplicationTests {

    @Test
    void contextLoads() {
    }

}
