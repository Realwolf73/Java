// PrintJobPriority.java
package com.example.printerqueue2.model;

public enum PrintJobPriority {
    NORMAL, HIGH
}