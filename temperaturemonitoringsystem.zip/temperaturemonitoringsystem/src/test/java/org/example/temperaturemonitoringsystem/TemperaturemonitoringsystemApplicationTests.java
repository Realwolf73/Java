package org.example.temperaturemonitoringsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TemperaturemonitoringsystemApplicationTests {

    @Test
    void contextLoads() {
    }

}
