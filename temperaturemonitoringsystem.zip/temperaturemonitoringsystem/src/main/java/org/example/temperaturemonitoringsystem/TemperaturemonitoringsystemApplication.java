package org.example.temperaturemonitoringsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TemperaturemonitoringsystemApplication {

    public static void main(String[] args) {
        SpringApplication.run(TemperaturemonitoringsystemApplication.class, args);
    }

}
