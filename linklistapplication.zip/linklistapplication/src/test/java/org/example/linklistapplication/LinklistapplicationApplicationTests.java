package org.example.linklistapplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LinklistapplicationApplicationTests {

    @Test
    void contextLoads() {
    }

}
