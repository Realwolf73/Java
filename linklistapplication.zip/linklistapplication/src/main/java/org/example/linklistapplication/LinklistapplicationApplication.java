package org.example.linklistapplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LinklistapplicationApplication {

    public static void main(String[] args) {
        SpringApplication.run(LinklistapplicationApplication.class, args);
    }

}
